var searchData=
[
  ['virtualearthtilelayer',['VirtualEarthTileLayer',['../class_unity_slippy_map_1_1_layers_1_1_virtual_earth_tile_layer.html',1,'UnitySlippyMap::Layers']]]
];
