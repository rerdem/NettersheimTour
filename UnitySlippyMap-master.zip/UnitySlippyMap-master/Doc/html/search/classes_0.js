var searchData=
[
  ['asyncinfo',['AsyncInfo',['../class_unity_slippy_map_1_1_map_1_1_tile_downloader_behaviour_1_1_async_info.html',1,'UnitySlippyMap::Map::TileDownloaderBehaviour']]]
];
