var searchData=
[
  ['identifier',['Identifier',['../class_unity_slippy_map_1_1_w_m_s_1_1_identifier.html',1,'UnitySlippyMap::WMS']]],
  ['imagerymetadata',['ImageryMetadata',['../class_unity_slippy_map_1_1_virtual_earth_1_1_imagery_metadata.html',1,'UnitySlippyMap::VirtualEarth']]]
];
