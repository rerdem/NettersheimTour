var searchData=
[
  ['request',['Request',['../class_unity_slippy_map_1_1_w_m_s_1_1_request.html',1,'UnitySlippyMap::WMS']]],
  ['resource',['Resource',['../class_unity_slippy_map_1_1_virtual_earth_1_1_resource.html',1,'UnitySlippyMap::VirtualEarth']]],
  ['resourceset',['ResourceSet',['../class_unity_slippy_map_1_1_virtual_earth_1_1_resource_set.html',1,'UnitySlippyMap::VirtualEarth']]]
];
